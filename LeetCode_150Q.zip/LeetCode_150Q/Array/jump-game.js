/*
  Greedy Approch
*/

const jumpGame = (arr) => {
  let reach = 0;
  for (let i = 0; i <= reach; i++) {
    reach = Math.max(reach, i + arr[i]);
    if (reach >= arr.length - 1) {
      return true;
    }
  }
  return false;
};

console.log(jumpGame([2, 2, 1, 0, 1, 4]));
console.log(jumpGame([2, 2, 1, 14]));
