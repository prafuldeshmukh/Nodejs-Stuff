const kadanes = (arr) => {
  let sum = arr[0],
    maxSum = arr[0];
  for (let i = 1; i < arr.length; i++) {
    if (sum >= 0) {
      sum = sum + arr[i];
    } else {
      sum = arr[i];
    }
    if (sum > maxSum) {
      maxSum = sum;
    }
  }
  return maxSum;
};
const maxSubArraySumCircular = (nums) => {
  if (nums.length == 0) return 0;
  let x = kadanes(nums);
  let y = 0;
  for (let i = 0; i < nums.length; i++) {
    y += nums[i];
    nums[i] *= -1;
  }
  let z = kadanes(nums);
  if (y + z === 0) return x;
  return Math.max(x, y + z);
};

//console.log(maxSubArraySumCircular([2, 1, -5, 4, -3, 1, -3, 4, 1]));
console.log(maxSubArraySumCircular([-3, -2, -3]));
