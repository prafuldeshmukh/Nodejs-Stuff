/*
  Median of two sorted arrays | O(log(m,n)) Time complexity 
*/

const findMedian = (arr1, arr2) => {
  let i = 0,
    j = 0,
    k = 0;
  //let m = Array.from({ length: arr1.length + arr2.length }, () => null);
  let m = new Array(arr1.length + arr2.length);
  while (i < arr1.length && j < arr2.length) {
    if (arr1[i] < arr2[j]) {
      m[k] = arr1[i];
      i++;
      k++;
    } else {
      m[k] = arr2[j];
      j++;
      k++;
    }
  }
  while (i < arr1.length) {
    m[k] = arr1[i];
    i++;
    k++;
  }
  while (j < arr2.length) {
    m[k] = arr2[j];
    j++;
    k++;
  }
  // If it is even no
  let mid = m.length / 2;
  mid = Math.floor(mid); // It basically rounds down a number to its nearest integer
  if (m.length % 2 === 0) {
    return (m[mid] + m[mid - 1]) / 2;
  } else {
    return m[mid];
  }
};

let arr1 = [1, 3, 8, 17];
let arr2 = [5, 6, 7, 19, 21];
[1, 3, 5, 6, 7, 8, 17, 19, 21];

console.log(findMedian(arr1, arr2));
