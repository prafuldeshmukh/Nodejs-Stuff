const findAllDuplicate = (arr) => {
  arr.sort((a, b) => a - b);
  let rd = 1;
  for (let i = 1; i <= arr.length; i++) {
    if (arr[rd] != arr[i]) {
      rd++;
      arr[rd] = arr[i];
    }
  }
  return arr.slice(0, rd);
};
const findAllDuplicate1 = (nums) => {
  let res = [];
  for (let i = 0; i < nums.length; i++) {
    let value = Math.abs(nums[i]);
    let index = value - 1;
    if (nums[index] < 0 && !res.includes(value)) {
      res.push(value);
    } else {
      nums[index] *= -1;
    }
  }
  return res;
};

console.log(findAllDuplicate([1, 3, 4, 2, 4, 3, 3, 4, 11, 12, 11]));
console.log(findAllDuplicate1([1, 3, 4, 2, 4, 3, 3, 4, 11, 12, 11]));
