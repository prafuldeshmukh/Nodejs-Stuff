const stockMaxProfit = (nums) => {
  let profit = 0,
    maxProfit = 0,
    min = nums[0];
  for (let stockPrice of nums) {
    min = Math.min(stockPrice, min);
    profit = stockPrice - min;
    maxProfit = Math.max(profit, maxProfit);
  }
  return maxProfit;
};

console.log(stockMaxProfit([7, 1, 5, 3, 6, 4])); // 5
console.log(stockMaxProfit([7, 6, 4, 3, 1])); // 0
