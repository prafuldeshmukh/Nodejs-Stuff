const findMajorityElem = (nums) => {
  let count = 1;
  let maj = nums[0];
  for (let i = 0; i < nums.length; i++) {
    if (nums[i] == maj) {
      count++;
    } else {
      count--;
    }
    if (count == 0) {
      maj = nums[i];
      count = 1;
    }
  }
  return maj;
};

console.log(findMajorityElem([5, 5, 8, 8, 8, 8, 1]));
