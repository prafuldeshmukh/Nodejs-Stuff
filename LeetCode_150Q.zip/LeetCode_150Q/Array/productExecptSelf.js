function productExceptSelf(nums) {
  const n = nums.length;
  const output = new Array(n);

  // Calculate the product of all elements to the left of each element
  let leftProduct = 1;
  for (let i = 0; i < n; i++) {
    output[i] = leftProduct;
    leftProduct *= nums[i];
  }

  // Calculate the product of all elements to the right of each element
  let rightProduct = 1;
  for (let i = n - 1; i >= 0; i--) {
    output[i] *= rightProduct;
    rightProduct *= nums[i];
  }

  return output;
}

// Example usage:
const nums = [1, 2, 3, 4];
console.log(productExceptSelf(nums)); // Output: [24, 12, 8, 6]

/*
const productExceptSelfBruteForce = (nums) => {
  const n = nums.length;
  const result = [];

  for (let i = 0; i < n; i++) {
    let product = 1;
    for (let j = 0; j < n; j++) {
      if (i !== j) {
        product *= nums[j];
      }
    }
    result.push(product);
  }

  return result;
};

// Example usage:
const nums = [1, 2, 3, 4];
console.log(productExceptSelfBruteForce(nums)); // Output: [24, 12, 8, 6]
*/
