/*
 i   j 
 0 - 0   1
 0 - 1   1 2
 0 - 2   1 2 3
 0 - 3   1 2 3 4
 0 - 4   1 2 3 4 5
 1 - 1   2
 1 - 2   2 3
 1 - 3   2 3 4
 1 - 4   2 3 4 5
*/

const findSubArr = (arr) => {
  for (let i = 0; i < arr.length; i++) {
    for (let j = i; j < arr.length; j++) {
      for (let k = i; k <= j; k++) {
        console.log(arr[k]);
      }

      console.log(" ............. ");
    }
  }
};

console.log(findSubArr([1, 2, 3, 4, 5]));
