// Using SLiding Window Approch
const maxSumSubArrayKthElem = (arr, k) => {
  let wSum = 0,
    mSum = -Infinity;
  for (let i = 0; i < arr.length; i++) {
    if (i != k) {
      wSum = wSum + arr[i];
    } else {
      wSum = wSum - arr[i - k] + arr[i];
      wSum = wSum / k;
      mSum = Math.max(wSum, mSum);
    }
  }
  return mSum;
};
console.log(maxSumSubArrayKthElem([1, 12, -5, -6, 50, 3], 4));
