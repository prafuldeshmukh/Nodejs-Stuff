/*
  O(n);
  Use Kadane's Alogrithm
  if sum it is in profit ie. sum >=0 then join business othrwise start new business
  find maxSum between sum & maxSum
*/

const findMaximumSubArrSum = (arr) => {
  let sum = arr[0],
    maxSum = arr[0];

  for (let i = 1; i < arr.length; i++) {
    if (sum >= 0) {
      // join
      sum = sum + arr[i];
    } else {
      // Don't join
      sum = arr[i];
    }
    if (sum > maxSum) {
      maxSum = sum;
    }
  }
  return maxSum;
};

//console.log(findMaximumSubArrSum([ 5, 4, -1, 7, 8 ]));
console.log(findMaximumSubArrSum([-3, -2, -3]));
