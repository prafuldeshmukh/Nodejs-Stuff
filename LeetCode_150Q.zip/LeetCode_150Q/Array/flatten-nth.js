const flattenArr = (arr, n) => {
  // store value in stack
  let stack = arr.map((item) => [item, n]);
  let res = [];
  while (stack.length) {
    // check the stack length
    // pop the value from stack
    const [item, depth] = stack.pop();
    if (Array.isArray(item) && depth > 0) {
      let subArr = item.map((elem) => [elem, depth - 1]);
      stack.push(...subArr);
    } else {
      res.push(item);
    }
  }
  res.reverse();
  return res;
};

const arr = [[[2, 3, [6, 7, 8, [9, 20]]]]];
// const arr = [
//   [1, 2, 3],
//   [6, 7],
// ];
console.log(flattenArr(arr, 4));
