const jumpGameSecond = (nums) => {
  let jump = 0,
    pos = 0,
    des = 0;

  for (let i = 0; i < nums.length - 1; i++) {
    des = Math.max(des, nums[i] + 1);
    if (pos == i) {
      pos = des;
      jump++;
    }
  }
  return jump;
};

console.log(jumpGameSecond([2, 3, 1, 1, 4]));
console.log(jumpGameSecond([2, 3, 0, 1, 4]));
