//const arr = [1,2,[3,4],[6,7],8,[9,0,[2,4,[7,8,[6,7],[0,1]]]]];
const arr = [
  [1, 2, 3],
  [4, 5, 6],
  [7, 8, [9, 10, 11], 12],
  [13, 14, 15],
];
const flattenArray = (arr) => {
  return arr.reduce((acc, curr) => {
    if (Array.isArray(curr)) {
      return acc.concat(flattenArray(curr));
    } else {
      return acc.concat(curr);
    }
  }, []);
};

// Test the function
const nestedArray = [1, [2, [3, 4], 5], 6];
const flattenedArray = flattenArray(nestedArray);
console.log(flattenedArray); // Output: [1, 2, 3, 4, 5, 6]

/*
const flattenArray = (arr) => {
  return arr.reduce((acc, curr) => {
    if (Array.isArray(curr)) {
      return [...acc, ...flattenArray(curr)];
    } else {
      return [...acc, curr];
    }
  }, []);
};

// Example usage
const nestedArray = [1, [2, 3], [4, [5, 6]]];
const flattenedArray = flattenArray(nestedArray);
console.log(flattenedArray); // Output: [1, 2, 3, 4, 5, 6]


*/

function outerFlat(arr, n) {
  function flatten(arr, level) {
    let result = [];
    for (let i = 0; i < arr.length; i++) {
      if (Array.isArray(arr[i]) && level < n) {
        result = result.concat(flatten(arr[i], level + 1));
      } else {
        result.push(arr[i]);
      }
    }
    return result;
  }
  return flatten(arr, 0);
}

console.log(outerFlat(arr, 6));
