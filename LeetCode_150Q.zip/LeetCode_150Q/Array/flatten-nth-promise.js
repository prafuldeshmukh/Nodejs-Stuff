const flattenAsync = (arr, n) => {
  const flatPromise = new Promise((resolve, reject) => {
    if (!Array.isArray(arr)) {
      reject(new Error("Input is not an array"));
      return;
    }
    let res = [];
    let stack = arr.map((item) => [item, n]);
    while (stack.length) {
      let [item, depth] = stack.pop();
      if (Array.isArray(item) && depth > 0) {
        let subArr = item.map((elem) => [elem, depth - 1]);
        stack.push(...subArr);
      } else {
        res.push(item);
      }
    }
    res.reverse();
    setTimeout(resolve(res), 1000);
  });
  return flatPromise;
};

const arr = [[[2, 3, [6, 7, 8, [9, 20]]]]];
flattenAsync(arr, 4)
  .then((res) => console.log(res))
  .catch((err) => console.log(err.message));
