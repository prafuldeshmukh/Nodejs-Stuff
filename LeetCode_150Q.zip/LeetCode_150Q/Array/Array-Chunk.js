const chunkData = (arr, chunkSize) => {
  let res = [];
  let subArr = [];
  for (let i = 0; i < arr.length; i++) {
    subArr.push(arr[i]);
    if (subArr.length === chunkSize) {
      res.push(subArr);
      subArr = [];
    }
  }
  if (subArr.length) {
    res.push(subArr);
  }
  return res;
};

console.log(chunkData([1, 2, 3, 4, 5], 2));

const chunkData1 = (arr, chunkSize) => {
  let res = [];
  for (let i = 0; i < arr.length; i += chunkSize) {
    let finalArr = arr.slice(i, i + chunkSize);
    res.push(finalArr);
  }
  return res;
};

console.log(chunkData1([1, 2, 3, 4, 5], 2));
