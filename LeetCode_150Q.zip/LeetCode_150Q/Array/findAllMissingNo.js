const findAllMissingNo = (arr) => {
  const maxNo = Math.max(...arr);
  const minNo = Math.min(...arr);
  let findArr = [];
  for (let k = minNo; k <= maxNo; k++) {
    if (!arr.includes(k)) {
      findArr.push(k);
    }
  }
  return findArr;
};

console.log(findAllMissingNo([0, 2, 7, 8, 1, 4, 3, 6, 12]));
