/*
   i/p = 2,7,9,18, target = 20
   o/p: 1,3
*/

const twoSum = (nums, target) => {
  let hashMap = {};
  for (let i = 0; i < nums.length; i++) {
    let potentialKey = target - nums[i];
    if (hashMap[potentialKey] >= 0 && hashMap[potentialKey] != i) {
      return [hashMap[potentialKey], i];
    } else {
      hashMap[nums[i]] = i;
    }
  }
  return "Matching array not found";
};

console.log(twoSum([2, 7, 9, 18], 20));

console.log(twoSum([3, 2, 3], 6));
