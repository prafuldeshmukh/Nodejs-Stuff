const reverse = (arr, start, end) => {
  while (start < end) {
    let temp = arr[start];
    arr[start] = arr[end];
    arr[end] = temp;
    start++;
    end--;
  }
};

const rotate = (arr, k) => {
  k = k % arr.length;
  if (k < 0) {
    k = k + arr.length;
  }

  reverse(arr, 0, k - 1); // Reverse the first k elements
  reverse(arr, k, arr.length - 1); //  Reverse the remaining elements after the first k elements
  reverse(arr, 0, arr.length - 1); // Reverse the entire array
  return arr;
};

const array = [1, 2, 3, 4, 5];
const rotations = 2; // ClockWise & AntiClowise
const rotatedArray = rotate(array, rotations);
console.log(rotatedArray); // Output: [4, 5, 1, 2, 3]
