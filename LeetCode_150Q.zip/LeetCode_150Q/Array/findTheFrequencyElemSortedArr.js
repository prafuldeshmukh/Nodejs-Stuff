const findFrequencyOfElem = (a) => {
  let freq = 1,
    i = 1;
  while (i < a.length) {
    while (i < a.length && a[i] === a[i - 1]) {
      freq++;
      i++;
    }
    console.log(a[i - 1] + " " + freq);
    freq = 1;
    i++;
  }
  if (a.length == 1 || a[i - 1] != a[i - 2]) {
    console.log(a[i - 1] + " " + freq);
  }
};

console.log(findFrequencyOfElem([20, 20, 30, 30, 30, 40]));
