/*
     => -1, 0, 1, 2, 1, 4
     => -1,0,1 
*/

const threeSum = (nums) => {
  let finResult = [];
  nums.sort((a, b) => a - b);
  for (let i = 0; i < nums.length; i++) {
    if (i == 0 || nums[i] != nums[i - 1]) {
      let target = 0 - nums[i];
      let res = twoSum(i + 1, nums.length, target, nums);
      finResult.push(...res);
    }
  }
  return finResult;
};

const twoSum = (leftPointer, rightPointer, target, nums) => {
  let a = nums[leftPointer - 1];
  let result = [];
  while (leftPointer < rightPointer) {
    let sum = nums[leftPointer] + nums[rightPointer];
    if (sum === target) {
      result.push([a, nums[leftPointer], nums[rightPointer]]);
      while (
        leftPointer < rightPointer &&
        nums[leftPointer] != nums[leftPointer + 1]
      )
        leftPointer++;
      while (
        leftPointer < rightPointer &&
        nums[rightPointer] != nums[rightPointer - 1]
      )
        rightPointer--;
      leftPointer++;
      rightPointer--;
    } else if (sum < target) {
      leftPointer++;
    } else {
      rightPointer--;
    }
  }
  return result;
};

console.log(threeSum([-1, 0, 1, 2, 1, 4]));
