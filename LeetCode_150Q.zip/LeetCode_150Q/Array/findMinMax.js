const findMinMax = (arr) => {
  if (arr.length == 0) return "no number found";
  let min = arr[0];
  let max = arr[1];
  for (let i = 0; i < arr.length; i++) {
    if (arr[i] < min) {
      min = arr[i];
    }
    if (arr[i] > max) {
      max = arr[i];
    }
  }
  console.log("min", min, "max", max);
};
console.log(findMinMax([2, 4, 3, 1, 10, 99, 23]));
