/**
 * @param {number[]} nums
 * @return {number[]}
 */
const findDuplicates = function (nums) {
  let result = [];
  for (let i = 0; i < nums.length; i++) {
    let Idx = Math.abs(nums[i]) - 1;
    let val = nums[Idx];
    if (val < 0) {
      result.push(Math.abs(nums[i]));
    } else {
      nums[Idx] = -nums[Idx];
    }
  }
  return result;
};

console.log(findDuplicates([4, 3, 2, 7, 8, 2, 3, 1]));
