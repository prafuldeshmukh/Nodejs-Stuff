/*
  [3,0,1]
  (n*(n+1)) / 2
  3 * 4 = 9+3 = 12 /2  =  6
  6 - 4 =2 
  // First will find the length
  // expectedTotal = n*(n+1) / 2
  // calculate total of all nums from array 
  // finally return expectedTotal - total 
*/

const findMissingNo = (arr) => {
  let n = arr.length;
  let expectedTotal = (n * (n + 1)) / 2;
  let total = 0;
  for (const num of arr) {
    total += num;
  }
  return expectedTotal - total;
};

console.log(findMissingNo([0, 3, 4, 1]));
const array = [9, 6, 4, 2, 3, 5, 7, 0, 1];

console.log("Missing number:", findMissingNo(array));
