/*
    Reverse Integer Nos:
    321
    123

*/

const reverseNos = (nums) => {
  let revNum = 0;
  while (nums != 0) {
    let digit = nums % 10;
    revNum = revNum * 10 + digit;
    nums = Math.trunc(nums / 10);
  }
  return revNum;
};

console.log(reverseNos(-321));
