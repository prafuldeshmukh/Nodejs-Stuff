const maxSumSubArrayKthElem = (arr, k) => {
  let wSum = 0,
    mSum = -Infinity;
  for (let i = 0; i < k; i++) {
    wSum = wSum + arr[i];
  }
  for (let i = k; i < arr.length; i++) {
    wSum = wSum - arr[i - k] + arr[i];
    mSum = Math.max(wSum, mSum);
  }
  return mSum;
};
console.log(maxSumSubArrayKthElem([2, 9, 31, -4, 21, 7], 3));
