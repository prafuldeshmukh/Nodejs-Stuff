/*
    nums = [4,5,6,7,8,9,10];  target = 14
    Two Pointer Method : [2,4]
*/

const twoSumTwoPointer = (nums, target) => {
  let leftPointer = 0,
    rightPointer = nums.length - 1;
  for (let i = 0; i < nums.length; i++) {
    let sum = nums[leftPointer] + nums[rightPointer];
    while (leftPointer < rightPointer) {
      if (sum == target) {
        return [nums[leftPointer], nums[rightPointer]];
      } else if (sum < target) {
        leftPointer++;
      } else {
        rightPointer--;
      }
    }
  }
  return false;
};

console.log(twoSumTwoPointer([4, 5, 6, 7, 8, 9, 10], 14));
