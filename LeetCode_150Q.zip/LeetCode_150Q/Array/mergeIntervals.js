const merge = (intervals) => {
  // sort the array
  intervals.sort((a, b) => a[0] - b[0]);
  const results = [intervals[0]];
  //console.log(results);
  for (let interval of intervals) {
    let e1 = results[results.length - 1][1];
    let s2 = interval[0];
    let e2 = interval[1];
    //console.log("Before", e1, s2, e2, results);
    if (e1 >= s2) {
      results[results.length - 1][1] = Math.max(e1, e2);
    } else {
      results.push(interval);
    }
    //console.log("After", e1, s2, e2, results);
  }
  return results;
};

console.log(
  merge([
    [1, 3],
    [2, 6],
    [8, 10],
    [15, 18],
  ])
); // o/p:[[1,6],[8,10],[15,18]]
console.log(
  merge([
    [1, 4],
    [4, 5],
  ])
);
