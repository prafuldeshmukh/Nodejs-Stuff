/*
 Using two pointer apporach

*/

const containerWithWater = (height) => {
  let left = 0,
    right = height.length - 1,
    max = 0;
  while (left < right) {
    let lh = height[left];
    let rh = height[right];
    let min_height = Math.min(lh, rh);
    let len = right - left;
    let current_area = min_height * len;
    max = Math.max(max, current_area);
    if (left < right) {
      left++;
    } else {
      right--;
    }
  }
  return max;
};

console.log(containerWithWater([1, 8, 6, 2, 5, 4, 8, 3, 7]));
