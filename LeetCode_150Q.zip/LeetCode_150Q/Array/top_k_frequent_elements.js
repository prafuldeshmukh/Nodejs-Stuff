/*
  [1,1,1,2,2,2,3];

  find the frequncy using map 
    map = {
       1:3
       2:2
       3:1
    }
    top 2 frequncy i want to written
    get the key element from object & use spread operator to convert in array
    u have to sort by  asceding value in map  - sort , We want no of frequncy element on top
     take last kth element from sorted array - slice

*/

const topKFreqEle = (arr, freq) => {
  let frqObj = {};
  for (let i = 0; i < arr.length; i++) {
    frqObj[arr[i]] = (frqObj[arr[i]] || 0) + 1;
  }
  const sortArr = [...Object.keys(frqObj)]
    .sort((a, b) => frqObj[b] - frqObj[a])
    .slice(0, freq);
  return sortArr;
};

console.log(topKFreqEle([10, 11, 1, 2, 2, 2, 3, 8, 9, 10, 10], 2));
