/**
 * @param {number[]} arr
 * @return {number[][]}
 */
var minimumAbsDifference = function (nums) {
  let result = [],
    min = Infinity;
  nums.sort((a, b) => a - b);

  for (let i = 0; i < nums.length - 1; i++) {
    let diff = nums[i + 1] - nums[i];
    min = Math.min(diff, min);
  }

  for (let i = 0; i < nums.length - 1; i++) {
    let diff = nums[i + 1] - nums[i];
    if (diff === min) {
      result.push([nums[i], nums[i + 1]]);
    }
  }
  return result;
};
console.log(minimumAbsDifference([4, 2, 1, 3]));
