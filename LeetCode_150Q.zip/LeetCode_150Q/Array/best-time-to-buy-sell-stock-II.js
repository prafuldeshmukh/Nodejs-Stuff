const stockMaxProfitII = (prices) => {
  let n = prices.length;
  let diff = 0;
  for (let i = 1; i < n; i++) {
    if (prices[i] > prices[i - 1]) diff += prices[i] - prices[i - 1];
  }
  return diff;
};

console.log(stockMaxProfitII([7, 1, 5, 3, 6, 4])); // 7
console.log(stockMaxProfitII([7, 6, 4, 3, 1])); // 0
