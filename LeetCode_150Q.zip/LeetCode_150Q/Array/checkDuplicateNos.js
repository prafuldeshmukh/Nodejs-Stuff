const findDuplicate = (nums) => {
  for (let i = 0; i < nums.length; i++) {
    let index = Math.abs(nums[i]);
    if (nums[index] < 0) {
      console.log(nums);
      return index;
    }
    nums[index] = -nums[index];
  }
};
console.log(findDuplicate([1, 3, 7, 6, 8, 9, 9, 10, 1]));
