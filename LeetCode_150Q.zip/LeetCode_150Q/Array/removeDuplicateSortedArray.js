const removeDuplicateSorted = (arr) => {
  let rd = 1;
  for (let i = 1; i <= arr.length; i++) {
    if (arr[rd] != arr[i]) {
      rd++;
      arr[rd] = arr[i];
    }
  }
  return arr.slice(0, rd);
};
let arr = [2, 3, 3, 3, 4, 6, 6];
console.log(removeDuplicateSorted(arr));
