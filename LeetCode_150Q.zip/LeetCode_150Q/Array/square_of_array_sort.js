/*
  o(nlogn)
*/

const squareSort = (arr) => {
  let res = [];
  let left = 0;
  let right = arr.length - 1;
  let i = right;
  while (left <= right) {
    let leftSquare = arr[left] ** 2;
    let rightSquare = arr[right] ** 2;
    if (leftSquare > rightSquare) {
      res[i--] = leftSquare;
      left++;
    } else {
      res[i--] = rightSquare;
      right--;
    }
  }
  return res;
};

console.log(squareSort([-3, -2, -1, 1, 2, 3, 4]));
/*
  square of sorted a array
  O(n)
*/

const squareOfSorted = (nums) => {
  const result = new Array(nums.length).fill(0);
  let left = 0,
    right = nums.length - 1,
    resultIdx = nums.length - 1;
  while (left <= right) {
    let leftVal = Math.pow(nums[left], 2);
    let rightVal = Math.pow(nums[right], 2);
    console.log(leftVal, rightVal);
    if (leftVal > rightVal) {
      result[resultIdx] = leftVal;
      left++;
    } else {
      result[resultIdx] = rightVal;
      right--;
    }
    resultIdx--;
  }
  return result;
};
console.log(squareOfSorted([-3, -2, -1, 1, 2, 3, 4]));
