const uniqueElementBuildMethod = (arr) => {
  let uniqueArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (!uniqueArr.includes(arr[i])) {
      uniqueArr.push(arr[i]);
    }
    /*if (uniqueArr.indexOf(arr[i]) === -1) {
      uniqueArr.push(arr[i]);
    }*/
    console.log("Unique Method");
  }
  return uniqueArr;
};
console.log(uniqueElementBuildMethod([1, 2, 3, 4, 1, 2, 3, 4, 5, 10, 9]));

const uniqueElement = (arr) => {
  let uniqueArr = [];
  for (let i = 0; i < arr.length; i++) {
    isDuplicate = false;
    for (let j = 0; j < uniqueArr.length; j++) {
      if (arr[i] == uniqueArr[j]) {
        isDuplicate = true;
      }
    }
    if (!isDuplicate) {
      uniqueArr.push(arr[i]);
    }
  }
  return uniqueArr;
};

console.log(uniqueElement([1, 2, 3, 4, 1, 2, 3, 4, 5, 10, 9]));

const uniqueElementUsingHashMap = (arr) => {
  let seen = {},
    uniqueArr = [];
  for (let i = 0; i < arr.length; i++) {
    if (!seen[arr[i]]) {
      uniqueArr.push(arr[i]);
      seen[arr[i]] = true;
    }
  }
  return uniqueArr;
};

console.log(uniqueElementUsingHashMap([1, 2, 3, 4, 1, 2, 3, 4, 5, 10, 9]));
let arr = [1, 2, 3, 4, 1, 2, 3, 4, 5, 10, 9];
console.log("Using Set", [...new Set(arr)]);
//Output: [1, 2, 3, 4, 5];
