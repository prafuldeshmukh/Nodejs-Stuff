/*

*/
const trailing_zeroes = (n) => {
  let res = 0,
    powerOf5 = 5;
  while (n >= powerOf5) {
    res = res + Math.trunc(n / powerOf5);
    powerOf5 = powerOf5 * 5;
  }
  return res;
};

console.log(trailing_zeroes(20));
