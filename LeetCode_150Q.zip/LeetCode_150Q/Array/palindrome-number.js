/*
  12341
  
*/

const isNoPlaindrome = (num) => {
  let temp = num,
    rev = 0;
  while (num != 0) {
    let digit = num % 10;
    rev = rev * 10 + digit;
    num = Math.trunc(num / 10);
  }
  console.log(num, temp);
  if (rev === temp) {
    return true;
  } else {
    return false;
  }
};

console.log(isNoPlaindrome(121));
console.log(isNoPlaindrome(-121));
console.log(isNoPlaindrome(10));
