/*             
    let arr = [5,6,7,8,9];
    o/p : [9,8,7,6,5]
    Swaping technique 
    i = 0
    j = arr.length -1;
    i = 0
    while(i < j){
      // swap the array value 
    }

*/

const reverse = (arr) => {
  let i = 0;
  let j = arr.length - 1;
  while (i < j) {
    let temp = arr[i];
    arr[i] = arr[j];
    arr[j] = temp;
    i++;
    j--;
  }

  return arr;
};

let arr = [5, 6, 7, 8, 9];
console.log(reverse(arr));
