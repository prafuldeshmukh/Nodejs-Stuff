/*

const numbers = [1, 2, 3, 2, 4, 5, 3, 6, 7, 7, 8];
create frequncyMap = {
     1:1
     2:2
     3:2
     4:1
     5:1
     6:1
     7:2
     8:1
}

find nums in frequncyMap which is unique no 
for num of numbers 
if(frequncyMap[num] === 1){
   // push the value nonDuplciate array
}
finally return nonDuplicate array

*/
const findNonDuplicates = (numbers) => {
  let frequncyMap = {};
  for (const num of numbers) {
    frequncyMap[num] = (frequncyMap[num] || 0) + 1;
  }
  let nonDuplicateNos = [];
  for (const num of numbers) {
    if (frequncyMap[num] === 1) {
      nonDuplicateNos.push(num);
    }
  }
  return nonDuplicateNos;
};
const numbers = [1, 2, 3, 2, 4, 5, 3, 6, 7, 7, 8];
console.log(findNonDuplicates(numbers)); //Output: [1, 4, 5, 6, 8]
