function isPrime(num) {
  if (num <= 1) {
    return false;
  }
  for (let i = 2; i <= Math.sqrt(num); i++) {
    if (num % i === 0) {
      return false;
    }
  }
  return true;
}

function findPrimes(upTo) {
  const primes = [];
  for (let i = 2; i <= upTo; i++) {
    if (isPrime(i)) {
      primes.push(i);
    }
  }
  return primes;
}

// Example usage:
const upTo = 5;
const primeNumbers = findPrimes(upTo);
console.log("Prime numbers up to", upTo, "are:", primeNumbers);
