async function mySuperProcessingTask() {
  const taskMessage = "Still Processing";

  // write logic for delayMe, so next console is printed after 5 second
  console.log(taskMessage);
  await delayMe(5000);

  console.log("Processing is Done");
}
mySuperProcessingTask();

async function delayMe(delaySecond) {
  // logic here for delay
  const delayData = setTimeout(() => {
    //console.log("i am here");
  }, delaySecond);
  return new Promise((resolve, reject) => {
    resolve(delayData);
  });
}
