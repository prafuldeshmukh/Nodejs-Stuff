// let getCountSum = (arr) => {
//   let sortedArr = arr.sort();
//   let number,
//     count = 0;

//   for (let i = 0; i < sortedArr.length; i++) {
//     if (sortedArr[i] === sortedArr[i - 1]) {
//       number = sortedArr[i];
//       count++;
//     }
//   }
//   return { count: count + 1, sum: number * 3 };
// };

let getCountSum = (arr) => {
  let countMap = {};
  for (let num of arr) {
    countMap[num] = (countMap[num] || 0) + 1;
  }
  let maxRepCount = 0,
    maxFrqElem;
  /*
  maxRepCount = Math.max(...Object.values(countMap));
  maxFrqElem = Object.keys(countMap).filter(
    (count) => countMap[count] === maxRepCount
  );*/
  for (let elem in countMap) {
    if (countMap[elem] > maxRepCount) {
      maxRepCount = countMap[elem];
      maxFrqElem = parseInt(elem);
    }
  }
  return { count: maxRepCount, sum: maxRepCount * +maxFrqElem.toString() };
};

let arr = [1, 2, 6, 4, 3, 6, 5, 8, 6, 8, 6, 6, 6];
console.log(getCountSum(arr));
