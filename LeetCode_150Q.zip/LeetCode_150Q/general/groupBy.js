const inventory = [
  { name: "asparagus", type: "vegetables", quantity: 5 },
  { name: "bananas", type: "fruit", quantity: 0 },
  { name: "goat", type: "meat", quantity: 23 },
  { name: "cherries", type: "fruit", quantity: 5 },
  { name: "fish", type: "meat", quantity: 22 },
];

// Grouping function using reduce
const groupBy = (array, key) => {
  return array.reduce((result, item) => {
    // Get the value of the key for the current item
    const groupValue = item[key];

    // Initialize an empty array for the group if it doesn't exist
    if (!result[groupValue]) {
      result[groupValue] = [];
    }

    // Push the current item to the group array
    result[groupValue].push(item);

    // Return the updated result
    return result;
  }, {});
};

// Grouping inventory items by the 'type' key
const groupedInventory = groupBy(inventory, "quantity");

console.log(groupedInventory);
