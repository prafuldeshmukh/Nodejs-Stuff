function binarySearchForPrefix(arr, prefix) {
  let left = 0;
  let right = arr.length - 1;
  let resultIndex = -1;

  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    const comparison = arr[mid].startsWith(prefix);

    if (comparison) {
      // Found a string that starts with the prefix
      resultIndex = mid;
      right = mid - 1; // Continue searching in the left half for earlier occurrences
    } else if (arr[mid] < prefix) {
      // Current string is less than the prefix, search in the right half
      left = mid + 1;
    } else {
      // Current string is greater than the prefix, search in the left half
      right = mid - 1;
    }
  }

  return resultIndex;
}

// Example usage:
const userList = [
  "abacus",
  "abbey",
  "abdomen",
  "able",
  "about",
  "above",
  "abracadabra",
];
const prefix = "ab";
const resultIndex = binarySearchForPrefix(userList, prefix);

if (resultIndex !== -1) {
  console.log(`Found "${userList[resultIndex]}" at index ${resultIndex}`);
} else {
  console.log(`No string starting with "${prefix}" found in the user list`);
}

// Test Case 1: Prefix present at the beginning of the array
const userList1 = [
  "abacus",
  "abbey",
  "abdomen",
  "able",
  "about",
  "above",
  "abracadabra",
];
const prefix1 = "ab";
const resultIndex1 = binarySearchForPrefix(userList1, prefix1);
console.log(resultIndex1); // Expected: 0 (index of "abacus")

// Test Case 2: Prefix present in the middle of the array
const userList2 = [
  "apple",
  "banana",
  "cherry",
  "grape",
  "orange",
  "strawberry",
];
const prefix2 = "c";
const resultIndex2 = binarySearchForPrefix(userList2, prefix2);
console.log(resultIndex2); // Expected: 2 (index of "cherry")

// Test Case 3: Prefix present at the end of the array
const userList3 = ["alpha", "beta", "gamma", "delta", "epsilon"];
const prefix3 = "e";
const resultIndex3 = binarySearchForPrefix(userList3, prefix3);
console.log(resultIndex3); // Expected: 4 (index of "epsilon")

// Test Case 4: Prefix not present in the array
const userList4 = ["cat", "dog", "fish", "horse", "lion"];
const prefix4 = "ze";
const resultIndex4 = binarySearchForPrefix(userList4, prefix4);
console.log(resultIndex4); // Expected: -1 (prefix not found)

// Test Case 5: Prefix present multiple times in the array
const userList5 = [
  "apple",
  "banana",
  "cherry",
  "grape",
  "orange",
  "strawberry",
];
const prefix5 = "s";
const resultIndex5 = binarySearchForPrefix(userList5, prefix5);
console.log(resultIndex5); // Expected: 5 (index of "strawberry") or any other index where "s" starts

// Test Case 6: Empty array
const userList6 = [];
const prefix6 = "a";
const resultIndex6 = binarySearchForPrefix(userList6, prefix6);
console.log(resultIndex6); // Expected: -1 (empty array)

// Test Case 7: Array with one element
const userList7 = ["apple"];
const prefix7 = "a";
const resultIndex7 = binarySearchForPrefix(userList7, prefix7);
console.log(resultIndex7); // Expected: 0 (index of "apple")

// Test Case 8: Array with duplicate elements
const userList8 = ["apple", "apple", "banana", "banana", "cherry", "cherry"];
const prefix8 = "b";
const resultIndex8 = binarySearchForPrefix(userList8, prefix8);
console.log(resultIndex8); // Expected: 2 (index of first occurrence of "banana")

// Test Case 9: Prefix with special characters
const userList9 = [
  "!apple",
  "#banana",
  "$cherry",
  "%grape",
  "&orange",
  "*strawberry",
];
const prefix9 = "$";
const resultIndex9 = binarySearchForPrefix(userList9, prefix9);
console.log(resultIndex9); // Expected: 2 (index of "$cherry")
