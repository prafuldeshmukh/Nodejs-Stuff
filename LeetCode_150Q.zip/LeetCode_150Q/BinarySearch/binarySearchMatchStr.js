function binarySearch(arr, target) {
  let left = 0;
  let right = arr.length - 1;

  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    const comparison = arr[mid].localeCompare(target);

    if (comparison === 0) {
      return mid; // Found the target string at index mid
    } else if (comparison < 0) {
      left = mid + 1; // Target is in the right half
    } else {
      right = mid - 1; // Target is in the left half
    }
  }

  return -1; // Target string not found
}

// Example usage:
const sortedArray = [
  "apple",
  "banana",
  "cherry",
  "grape",
  "orange",
  "strawberry",
];
const targetString = "grape";
const resultIndex = binarySearch(sortedArray, targetString);

if (resultIndex !== -1) {
  console.log(`Found "${targetString}" at index ${resultIndex}`);
} else {
  console.log(`"${targetString}" not found in the array`);
}
