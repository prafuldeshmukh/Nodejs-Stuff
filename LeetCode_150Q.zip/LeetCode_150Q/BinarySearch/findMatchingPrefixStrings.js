function findMatchingPrefixStrings(arr, prefix) {
  const matchingStrings = [];

  for (let str of arr) {
    if (str.startsWith(prefix)) {
      matchingStrings.push(str);
    }
  }

  return matchingStrings;
}

// Example usage:
const userList = [
  "abacus",
  "abbey",
  "abdomen",
  "able",
  "about",
  "above",
  "abracadabra",
];
const prefix = "ab";
const matchingStrings = findMatchingPrefixStrings(userList, prefix);
console.log(matchingStrings);
