function binarySearchForPrefixRange(arr, prefix) {
  let left = 0;
  let right = arr.length - 1;
  let startIdx = -1;
  let endIdx = -1;

  // Find the starting index of the prefix
  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    if (arr[mid].startsWith(prefix)) {
      startIdx = mid;
      right = mid - 1; // Continue searching in the left half for earlier occurrences
    } else if (arr[mid] < prefix) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }

  // Find the ending index of the prefix
  left = 0;
  right = arr.length - 1;
  while (left <= right) {
    const mid = Math.floor((left + right) / 2);
    if (arr[mid].startsWith(prefix)) {
      endIdx = mid;
      left = mid + 1; // Continue searching in the right half for later occurrences
    } else if (arr[mid] < prefix) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }

  // Extract strings within the range [startIdx, endIdx]
  const matchedStrings = [];
  for (let i = startIdx; i <= endIdx; i++) {
    matchedStrings.push(arr[i]);
  }

  return matchedStrings;
}

// Example usage:
const userList = [
  "abacus",
  "abbey",
  "abdomen",
  "able",
  "mpout",
  "above",
  "xdracadabra",
];
const prefix = "mp";
const matchedStrings = binarySearchForPrefixRange(userList, prefix);

if (matchedStrings.length > 0) {
  console.log(`Strings starting with "${prefix}":`, matchedStrings);
} else {
  console.log(`No strings starting with "${prefix}" found in the user list`);
}
