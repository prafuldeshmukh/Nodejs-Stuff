/*
  input = [()]
  o/p = true
*/

const isValidPareth = (str) => {
  let stack = [],
    i = 0;
  let matchPattern = "[](){}";
  while (i < str.length) {
    stack.push(str[i]);
    i++;
    let open = stack[stack.length - 2];
    let close = stack[stack.length - 1];
    let comParen = open + close;
    if (matchPattern.includes(comParen)) {
      stack.pop();
      stack.pop();
    }
  }
  return stack.length === 0;
};

console.log(isValidPareth("[()"));
