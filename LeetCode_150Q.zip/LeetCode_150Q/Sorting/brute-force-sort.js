let arr = [2, 7, 6, 5, 6, 20];

const sortArr = (nums) => {
  for (let i = 0; i < nums.length; i++) {
    for (let j = i; j < nums.length; j++) {
      if (nums[i] > nums[j]) {
        let temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
      }
    }
  }
  return nums;
};

console.log(sortArr(arr));

/*

const sortArr = (nums) => {
  const len = nums.length;
  for (let i = 0; i < len; i++) {
    for (let j = i + 1; j < len; j++) {
      if (nums[i] > nums[j]) {
        [nums[i], nums[j]] = [nums[j], nums[i]]; // Swap elements using destructuring assignment
      }
    }
  }
  return nums;
};

let arr = [2, 7, 6, 5, 6, 20];
console.log(sortArr(arr));

*/
