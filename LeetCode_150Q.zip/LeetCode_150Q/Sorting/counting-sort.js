function countingSort(arr) {
  const max = Math.max(...arr);
  const counts = new Array(max + 1).fill(0);

  // Count occurrences of each element in the input array
  for (let num of arr) {
    counts[num]++;
  }
  console.log(counts);

  // Construct the sorted output array
  let sortedArray = [];
  for (let i = 0; i <= max; i++) {
    while (counts[i] > 0) {
      sortedArray.push(i);
      counts[i]--;
    }
  }

  return sortedArray;
}

// Example usage:
let arr = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5];
console.log("Original array:", arr);
console.log("Sorted array:", countingSort(arr));
