const firstOccStr = (haystack, needle) => {
  let n = haystack.length - needle.length + 1;
  for (let i = 0; i < n; i++) {
    if (haystack.charAt(i) == needle.charAt(0)) {
      let hStackStr = haystack.substr(i, needle.length);
      if (hStackStr == needle) {
        return i;
      }
    }
  }
  return -1;
};

console.log(firstOccStr("sadbutsad", "sad"));
