function isPrefixOfWord(sentence, searchWord) {
  const words = sentence.split(" ");

  for (let i = 0; i < words.length; i++) {
    if (words[i].startsWith(searchWord)) {
      return i + 1; // Return the 1-based index of the word if found
    }
  }

  return -1; // Return -1 if the word is not found as a prefix
}

// Example usage:
const sentence = "i love eating burger";
const searchWord = "burg";
console.log(isPrefixOfWord(sentence, searchWord)); // Output: 4
