function reverseWords(str) {
  // Split the string into an array of words
  const words = str.trim().split(/\s+/);
  // Reverse the array of words
  const reversedWords = words.reverse();
  // Join the array back into a string with spaces between the words
  return reversedWords.join(" ");
}

// Example usage
console.log(reverseWords("the sky is blue")); // Output: "blue is sky the"
console.log(reverseWords("  hello world  ")); // Output: "world hello"
