const LengthOfLastWords = (str) => {
  let str1 = str.trim();
  let count = 0;
  for (let i = str1.length - 1; i >= 0; i--) {
    if (str1.charAt(i) != " ") {
      count++;
    } else {
      break;
    }
  }
  return count;
};

console.log(LengthOfLastWords("   fly me   to   the moon  "));
