function isVowel(char) {
  return ["a", "e", "i", "o", "u"].includes(char);
}

function countVowelStrings(words, left, right) {
  let count = 0;

  for (let i = left; i <= right; i++) {
    const word = words[i];
    if (isVowel(word[0]) && isVowel(word[word.length - 1])) {
      count++;
    }
  }

  return count;
}

// Example usage:
const words = ["are", "amy", "u"];
const left = 0;
const right = 2;
console.log(countVowelStrings(words, left, right)); // Output: 2
