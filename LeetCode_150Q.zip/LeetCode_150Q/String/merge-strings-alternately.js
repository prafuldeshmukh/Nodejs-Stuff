const mergeAlternately = (str1, str2) => {
  let i = 0,
    j = 0,
    result = "";

  while (i < str1.length && j < str2.length) {
    result += str1[i++];
    result += str2[j++];
  }

  while (i < str1.length) {
    result += str1[i++];
  }
  while (j < str2.length) {
    result += str2[j++];
  }
  return result;
};

// Example usage
console.log(mergeAlternately("abc", "def")); // Output: "adbecf"
console.log(mergeAlternately("ab", "pqrs")); // Output: "apbqrs"
