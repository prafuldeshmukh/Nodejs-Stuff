function reverseOnlyLetters(s) {
  const isLetter = (char) => /[a-zA-Z]/.test(char);

  let left = 0,
    right = s.length - 1;
  const chars = s.split("");

  while (left < right) {
    if (isLetter(chars[left]) && isLetter(chars[right])) {
      [chars[left], chars[right]] = [chars[right], chars[left]];
      left++;
      right--;
    } else if (!isLetter(chars[left])) {
      left++;
    } else {
      right--;
    }
  }

  return chars.join("");
}

// Example usage:
console.log(reverseOnlyLetters("ab-cd")); // Output: "dc-ba"
console.log(reverseOnlyLetters("a-bC-dEf-ghIj")); // Output: "j-Ih-gfE-dCba"
