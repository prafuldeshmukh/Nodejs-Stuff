function findMaxConsecutiveString(str) {
  let maxCount = 0;
  let currentCount = 1;
  let consecutiveString = "";
  let currentConsecutiveString = str[0];

  for (let i = 1; i < str.length; i++) {
    if (
      str[i] === str[i - 1] ||
      str[i].toLowerCase() === str[i - 1].toLowerCase()
    ) {
      currentCount++;
      currentConsecutiveString += str[i];
    } else {
      if (currentCount > maxCount) {
        maxCount = currentCount;
        consecutiveString = currentConsecutiveString;
      }
      currentCount = 1;
      currentConsecutiveString = str[i];
    }
  }

  if (currentCount > maxCount) {
    maxCount = currentCount;
    consecutiveString = currentConsecutiveString;
  }

  return consecutiveString;
}

// Example usage:
console.log(findMaxConsecutiveString("UuHIJKkkih")); // Output: "kkk"
