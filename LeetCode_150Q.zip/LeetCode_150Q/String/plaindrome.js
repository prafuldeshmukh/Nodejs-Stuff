const plaindrome = (str) => {
  let revStr = "";
  for (let i = str.length - 1; i >= 0; i--) {
    revStr = revStr + str.charAt(i);
  }
  if (str.toLowerCase() === revStr.toLowerCase()) {
    return true;
  } else {
    return false;
  }
};
console.log(plaindrome("Radar"));
