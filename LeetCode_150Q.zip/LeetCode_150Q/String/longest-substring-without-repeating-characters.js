const lengthOfLongSubStr = (s) => {
  let max = 0;
  let windowStart = 0;
  const map = {};

  for (let windowEnd = 0; windowEnd <= s.length; windowEnd++) {
    let rightChar = s[windowEnd];
    map[rightChar] = map[rightChar] + 1 || 1;

    while (map[rightChar] > 1) {
      let leftChar = s[windowStart];
      if (map[leftChar] > 1) {
        map[leftChar]--;
      } else {
        console.log("map[leftChar] before", map[leftChar], JSON.stringify(map));

        delete map[leftChar];
        console.log("map[leftChar] after", leftChar, JSON.stringify(map));
      }
      windowStart++;
    }
    max = Math.max(max, windowEnd - windowStart + 1);
  }
  return max;
};

console.log(lengthOfLongSubStr("abcabcbb")); // 3 abc
/*
 a b c a b c b b

 start   end   max 
  0       0    0
  0       1    1
  0       2    2 
  1       3    2
  2       4    2
  3       5    2
  4        6     
 map {
   a:1
   b:1
   c:1
 }
*/
