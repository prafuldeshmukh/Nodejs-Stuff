function reverseWords(str) {
  let reversed = "";
  let word = "";

  // Iterate over each character in the string
  for (let char of str) {
    // If the character is not a space, add it to the current word
    if (char !== " ") {
      word += char;
    } else {
      // If the character is a space, add the current word to the beginning of the result string
      reversed = word + " " + reversed;
      word = ""; // Reset the current word
    }
  }

  // Add the last word to the beginning of the result string
  reversed = word + " " + reversed;

  return reversed.trim(); // Remove trailing space
}

// Example usage
console.log(reverseWords("Hello World")); // Output: "World Hello"
console.log(reverseWords("The quick brown fox")); // Output: "fox brown quick The"
