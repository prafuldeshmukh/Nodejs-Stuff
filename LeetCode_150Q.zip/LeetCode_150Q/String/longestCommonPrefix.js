const longestCommonPrefix = (str) => {
  str.sort();
  let str1 = str[0],
    str2 = str[str.length - 1],
    index = 0;

  while (index < str1.length) {
    if (str1.charAt(index) == str2.charAt(index)) {
      index++;
    } else {
      break;
    }
  }
  return index == 0 ? "" : str1.substr(0, index);
};

// Test cases
console.log(longestCommonPrefix(["flower", "flow", "flight"])); // Output: "fl"
console.log(longestCommonPrefix(["dog", "racecar", "car"])); // Output: ""
