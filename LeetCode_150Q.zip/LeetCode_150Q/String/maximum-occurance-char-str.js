const maximumOccCharStr = (str) => {
  let chars = str.toLowerCase().split(""); // Convert to lowercase to ignore case sensitivity
  let map = {};
  for (let i = 0; i < chars.length; i++) {
    map[chars[i]] = (map[chars[i]] || 0) + 1;
  }
  console.log(map);
  let max = 0; // Initialize max count
  let newChar = ""; // Initialize newChar
  for (let k in map) {
    if (map[k] > max) {
      max = map[k];
      newChar = k;
    }
  }
  return { char: newChar, count: max }; // Return both character and its count
};

console.log(maximumOccCharStr("UuhlKkkdm"));
