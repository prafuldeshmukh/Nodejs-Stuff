/*

I Love India => i/p

a idnI evoLI => o/p  

=> for  i = str.length -1; i > = 0; i--
 first i will reverse string without including space & store in one array
=> iterate main str without reverse , find the space between & modify existing reverse str array on that index
   space
=> finally join that array
*/

const reverseSpacing = (str) => {
  let reverStr = [];
  for (let i = str.length - 1; i >= 0; i--) {
    if (str[i].indexOf(" ") != 0) {
      reverStr.push(str.charAt(i));
    }
  }
  for (let i = 0; i < str.length - 1; i++) {
    if (str[i].indexOf(" ") >= 0) {
      reverStr.splice(i, 0, " ");
    }
  }
  return reverStr.join("");
};

console.log(reverseSpacing("I Love India"));
