function reverseWords(str) {
  // Function to reverse characters in a string
  function reverseString(s) {
    let reversed = "";
    for (let i = s.length - 1; i >= 0; i--) {
      reversed += s[i];
    }
    return reversed;
  }

  let reversedStr = "";
  let word = "";

  // Iterate through each character in the string
  for (let char of str) {
    // If the character is not a space, append it to the current word
    if (char !== " ") {
      word += char;
    } else {
      // If a space is encountered, reverse the current word and append it to the result
      reversedStr += reverseString(word) + " ";
      word = ""; // Reset the current word
    }
  }

  // Reverse the last word and append it to the result
  reversedStr += reverseString(word);

  return reversedStr;
}

// Example usage
console.log(reverseWords("Hello World")); // Output: "olleH dlroW"
console.log(reverseWords("The quick brown fox")); // Output: "ehT kciuq nworb xof"
