function findTheDifference(s, t) {
  let charCount = {};

  // Count occurrences of each character in string t
  for (let char of t) {
    charCount[char] = (charCount[char] || 0) + 1;
  }

  // Subtract occurrences of characters in string s
  for (let char of s) {
    charCount[char]--;
  }

  // Find the character with count 1 in t
  for (let char in charCount) {
    if (charCount[char] === 1) {
      return char;
    }
  }

  return ""; // Default return if not found
}

// Example usage:
console.log(findTheDifference("abcd", "abcde")); // Output: 'e'
console.log(findTheDifference("", "y")); // Output: 'y'
console.log(findTheDifference("a", "aa")); // Output: 'a'
