const isSubsequence = (s, t) => {
  if (s.length == 0) return true;
  let j = 0;
  for (let i = 0; i < t.length; i++) {
    if (t.charAt(i) == s.charAt(j)) {
      // If it is match
      j++;
    }
    if (j >= s.length) return true;
  }
  return false;
};

console.log(isSubsequence("abc", "pqarsbd"));
