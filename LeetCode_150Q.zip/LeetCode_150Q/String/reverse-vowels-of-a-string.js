const reverseVowels = (str) => {
  let chars = str.split("");
  let left = 0;
  let right = chars.length - 1;
  while (left < right) {
    //console.log("Hi", !isVowel(chars[left]));
    if (!isVowel(chars[left])) {
      left++;
    } else if (!isVowel(chars[right])) {
      right--;
    }
    if (isVowel(chars[left]) && isVowel(chars[right])) {
      let temp = chars[left];
      chars[left] = chars[right];
      chars[right] = temp;
      left++;
      right--;
    }
  }
  return chars.join("");
};
const isVowel = (char) => {
  return ["a", "e", "i", "o", "u", "A", "E", "I", "O", "u"].includes(char);
};

console.log(reverseVowels("hello")); // Output: "holle"
console.log(reverseVowels("leetcode")); // Output: "leotcede"
