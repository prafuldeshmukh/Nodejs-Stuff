const reverStr = (str) => {
  let reverse = "";
  for (let i = str.length - 1; i >= 0; i--) {
    reverse += str[i];
  }
  return reverse;
};

const reverStr1 = (str) => {
  let reverse = "";
  str = str.split(" ");
  for (let i = str.length - 1; i >= 0; i--) {
    reverse += str[i] + " ";
  }
  return reverse;
};

console.log(reverStr1("I Love My India"));
