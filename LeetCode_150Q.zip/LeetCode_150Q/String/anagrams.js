const isAnagrams = (sourceStr, targetSrc) => {
  if (sourceStr.length != targetSrc.length) return false;
  //sourceStr = sourceStr.replace(/\s/g, "");
  //targetSrc = targetSrc.replace(/\s/g, "");
  let mapCounter = {};
  for (let letter of sourceStr) {
    mapCounter[letter] = (mapCounter[letter] || 0) + 1;
  }
  for (let item of targetSrc) {
    if (!mapCounter[item]) {
      return false;
    } else {
      mapCounter[item] -= 1;
    }
  }
  return true;
};

console.log(isAnagrams("keep I am here", "peek I am here"));
