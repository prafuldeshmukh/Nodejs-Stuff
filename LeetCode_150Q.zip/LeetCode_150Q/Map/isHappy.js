const isHappy = (n) => {
  let hashMap = {};
  while (n !== 1) {
    let current = n;
    let sum = 0;
    while (current !== 0) {
      sum = sum + (current % 10) ** 2;
      current = Math.floor(current / 10);
    }
    if (hashMap[sum]) {
      return false;
    }
    hashMap[sum] = true;
    n = sum;
  }
  return true;
};

console.log(isHappy(20));
