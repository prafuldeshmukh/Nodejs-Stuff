/*
  
  IV
  I  - 1
  V  - 5
  let map = {
    I:1,
    V:5
  }
  result = 0, preVal = 0, 
  for(len(char) -1 to 0 ){
      currVal = char[i];
      if(currval < preval){
         result = result - currval;
      } else {
        result = result - curval
      }
      preVal = currVal
  }
*/

const romanToInt = (roman) => {
  let result = 0,
    preVal = 0;
  const romanNumerals = {
    I: 1,
    V: 5,
    X: 10,
    L: 50,
    C: 100,
    D: 500,
    M: 1000,
  };
  for (let i = roman.length - 1; i >= 0; i--) {
    let currVal = romanNumerals[roman[i]];
    if (currVal < preVal) {
      result = result - currVal;
    } else {
      result = result + currVal;
    }
    preVal = currVal;
  }
  return result;
};

// Test cases
console.log(romanToInt("III")); // Output: 3
console.log(romanToInt("IV")); // Output: 4
console.log(romanToInt("IX")); // Output: 9
console.log(romanToInt("LVIII")); // Output: 58
console.log(romanToInt("MCMXCIV")); // Output: 1994
