const longestConsecutive = (nums) => {
  const hm = {};
  for (let i = 0; i < nums.length; i++) {
    hm[nums[i]] = true;
  }

  for (let i = 0; i < nums.length; i++) {
    if (hm[nums[i] - 1] !== undefined) {
      hm[nums[i]] = false;
    }
  }

  let max = 0;
  for (let key in hm) {
    if (hm[key] === true) {
      max = Math.max(max, findLength(hm, parseInt(key)));
    }
  }
  return max;
};

const findLength = (hm, k) => {
  let ans = 0;
  while (hm[k] != undefined) {
    ans++;
    k++;
  }
  return ans;
};

// Test case
console.log(longestConsecutive([100, 4, 200, 1, 3, 2])); // Output: 4
