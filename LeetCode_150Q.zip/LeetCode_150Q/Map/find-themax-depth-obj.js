function findMaxDepth(obj) {
  let maxDepth = 0;

  function traverse(obj, depth) {
    // Update maxDepth if current depth is greater
    if (depth > maxDepth) {
      maxDepth = depth;
    }

    // Recursively traverse nested objects
    for (const key in obj) {
      if (typeof obj[key] === "object") {
        traverse(obj[key], depth + 1);
      }
    }
  }

  // Start traversal with initial depth 1
  traverse(obj, 1);

  return maxDepth;
}

let depthObj = {
  a: 1,
  b: 2,
  c: {
    d: 3,
    e: 4,
    f: {
      g: 5,
      h: {
        i: 6,
        j: 7,
        k: {
          l: 8,
          m: 3,
          s: {
            kk: 8,
            tt: 10,
          },
        },
      },
    },
  },
};

console.log(findMaxDepth(depthObj)); // Output: 5
