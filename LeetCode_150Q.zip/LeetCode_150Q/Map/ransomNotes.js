const ransomNotes = (ransomNote, magazine) => {
  const charCount = {};

  for (const ch of magazine) {
    charCount[ch] = (charCount[ch] || 0) + 1;
  }

  for (const ch of ransomNote) {
    if (!charCount[ch]) {
      return false;
    }
    charCount[ch]--;
  }

  return true;
};

// Test case
console.log(ransomNotes("aa", "aab")); // Output: true
console.log(ransomNotes("aas", "aab")); // Output: false
