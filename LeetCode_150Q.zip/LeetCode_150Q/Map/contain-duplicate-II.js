const containsNearbyDuplicate = (nums, k) => {
  const hashMap = {};
  for (let i = 0; i < nums.length; i++) {
    const num = nums[i];
    if (hashMap[num] != undefined && i - hashMap[num] <= k) {
      return true;
    }
    hashMap[num] = i;
  }
  return false;
};

// Test cases
console.log(containsNearbyDuplicate([1, 2, 3, 1], 3)); // true
console.log(containsNearbyDuplicate([1, 0, 1, 1], 1)); // true
console.log(containsNearbyDuplicate([1, 2, 3, 1, 2, 3], 2)); // false
