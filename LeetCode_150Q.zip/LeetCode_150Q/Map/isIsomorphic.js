/*

*/
const isIsomorphic = (s, t) => {
  if (s.length != t.length) {
    return false;
  }
  const mapS = {},
    mapT = {};

  for (let i = 0; i < s.length; i++) {
    const charS = s[i];
    const charT = t[i];
    // check the chars are already mapped, check if the match
    if (mapS[charS]) {
      if (mapS[charS] !== charT) {
        return false;
      }
    } else {
      mapS[charS] = charT;
    }

    // same check for othe string
    if (mapT[charT]) {
      if (mapT[charT] !== charS) {
        return false;
      }
    } else {
      mapT[charT] = charS;
    }
  }
  return true;
};

// Test cases
console.log(isIsomorphic("egg", "add")); // true
console.log(isIsomorphic("foo", "bar")); // false
console.log(isIsomorphic("paper", "title")); // true
