/*
   Example 1:

Input: strs = ["eat","tea","tan","ate","nat","bat"]
Output: [["bat"],["nat","tan"],["ate","eat","tea"]]
Example 2:

Input: strs = [""]
Output: [[""]]
Example 3:

Input: strs = ["a"]
Output: [["a"]]


*/

const groupAnagrams = (str) => {
  const sortedStr = str.map((word) => word.split("").sort().join(""));
  const hashMap = {};
  for (let i = 0; i < str.length; i++) {
    if (!hashMap[sortedStr[i]]) {
      hashMap[sortedStr[i]] = [str[i]];
    } else {
      hashMap[sortedStr[i]].push(str[i]);
    }
  }
  return Object.values(hashMap);
};
console.log(groupAnagrams(["eat", "tea", "tan", "ate", "nat", "bat"]));
