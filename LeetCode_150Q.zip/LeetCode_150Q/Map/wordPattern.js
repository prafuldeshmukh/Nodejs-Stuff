const wordPattern = (pattern, s) => {
  // split the string as words
  const words = s.split(" ");
  if (pattern.length != words.length) {
    return false;
  }
  const mapPattern = {};
  const mapWords = {};
  for (let i = 0; i < pattern.length; i++) {
    const char = pattern[i];
    const word = words[i];

    if (mapPattern[char]) {
      if (mapPattern[char] !== word) {
        return false;
      }
    } else {
      mapPattern[char] = word;
    }

    if (mapWords[word]) {
      if (mapWords[word] !== char) {
        return false;
      }
    } else {
      mapWords[word] = char;
    }
  }
  return true;
};

// Test cases
console.log(wordPattern("abba", "dog cat cat dog")); // true
console.log(wordPattern("abba", "dog cat cat fish")); // false
console.log(wordPattern("aaaa", "dog cat cat dog")); // false
console.log(wordPattern("abba", "dog dog dog dog")); // false
