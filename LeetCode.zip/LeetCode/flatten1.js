

var flat = function(arr, n){
    let stack = arr.map(item=>[item, n]);
    let res = [];    
    while(stack.length){
        let [item ,depth] = stack.pop();
        if(Array.isArray(item) && depth > 0){
            stack.push(...item.map(el=> [el, depth-1]));
            console.log("stack", stack);
        } else {
            res.push(item);
        }
    }
    return res.reverse();
}
/*
Dry Run 
[[1,2,3]]

*/ 
//const arr = [[1, 2, 3], [4, 5, 6,[100,101,[102,103]]], [7, 8, [9, 10, 11], 12], [13, 14, 15]];
const arr = [[1,2,3,[4,5]],[6,7]]
console.log(flat(arr,3));