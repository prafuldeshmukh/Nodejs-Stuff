/*
         *
       * *
     * * *
  *  * * *
* *  * * *

n = 5
i = 1 // rows
j = 1  // columns
k = 1  // space

i    k    j
1    4    1
2    3    2
3    2    3
4    1    4
5    0    5

relation between i & j - i<=j
relation between  k & j = k = n - i

i    k    j
1    1    4
2    2    3
3    3    2
4    4    1
5    5    0

k<=i in case of k 

j=n-i
j>=1
in case of j
  1
1 2 1
1 3 2 1
1
1 2 1
1 3 2 1

*/

const pattern = (n)=>{
    let pattern = "";
    for(let i=1;i<=n;i++){
        for(let k =1;k<=n-i;k++){
            pattern+=" ";
        }
        for(let j =1;j<=i;j++){
           // pattern+=j+" ";
            pattern+="*"+" ";
        }
        pattern+="\n";
    }
    for(let i=1;i<=n;i++){
        for(let k =1;k<=i;k++){
            pattern+=" ";
        }
        for(let j =n-i;j>=1;j--){
            //pattern+=j+" ";
            pattern+="*"+" ";
        }
        pattern+="\n";
    }
    console.log(pattern);
}
pattern(5);
