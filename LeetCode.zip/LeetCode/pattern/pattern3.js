let counter = 4

function recurr(counter,i){

let arr = []

    for (let z=1; z <= i; z++){

        arr.push(z) 

    }

    for (let j=counter; j>0; j--){

        if(j < i){

            arr.push(j) 

        }

    }

    if(i < counter){

        for(let c=i;c < counter; c++){

            arr.unshift(' ')

        }

    }

    console.log(arr.join(' '))

}
 
for(let i= 1;i <= counter;i++){

recurr(counter,i) 

  if(i == counter){

        for(let j=counter-1; j>0; j--){

            recurr(counter,j)

        }

    }

}