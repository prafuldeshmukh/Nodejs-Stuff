/*
      1
    1 2 1
  1 2 3 2 1
1 2 3 4 3 2 1
     j<2*i-1 - value
     k<n-i - space         
i   space  j
1    3     1
2    2     3
3    1     4
4    0     5
*/

const pattern2 = (n)=>{
    let patternVal = "";
    for(let i = 1;i<=n;i++){
        for(let k = 1; k<=n-i;k++){
            patternVal+=" ";
        }
        for(let j=1;j<=2*i-1;j++){
            patternVal+=j+" ";
        }
        patternVal+="\n";
    }
    console.log(patternVal);
  
}
console.log(pattern2(4));