

const frqCount = (newArr, name) => {
    let count = {};
    for (let i = 0; i < newArr.length; i++) {
        if (name == newArr[i]) {
            if (count[newArr[i]]) {
                count[newArr[i]] += 1;
            } else {
                count[newArr[i]] = 1;
            }
        }
    }
    return count;
}

let newarr = ['akshay', 'akshay', 'dinesh', 'viraj', 'dinesh', 'viraj', 'pratik'];
console.log(frqCount(newarr,'akshay'));