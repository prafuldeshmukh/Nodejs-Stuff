/*let str = "I Love My India";
console.log(str.split('').reverse().join(''));
*/
/*
let str = "I Love My India";
let reverStr = [];
for(let i = str.length -1;i>=0;i--){
    if(str[i].indexOf(' ') != 0){
      reverStr.push(str.charAt(i));
    } 
}
for(let i = 0;i<str.length;i++){
    if(str[i].indexOf(' ') >= 0){
      reverStr.splice(i, 0,' ');
    }
}
console.log(reverStr.join(''));
*/
let s = ["h","e","l","l","o"];
let revStr = [];
for(let i = s.length-1;i>=0;i--){
    revStr.push(s[i]);
}
console.log(revStr);
//console.log(reverStr);