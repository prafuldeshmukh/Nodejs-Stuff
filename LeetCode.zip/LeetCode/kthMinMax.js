
const kMinmax = (nums, k) =>{
    let sortArray = nums.sort((a,b)=> a-b);
    return sortArray[k-1];
}


console.log(kMinmax([4,5,6,10], 3));