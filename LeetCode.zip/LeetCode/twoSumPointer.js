
const twoSum = (arr, target)=>{
    let nums = arr.sort((a,b)=> a-b);
    let leftPointer = 0, rightPointer = nums.length - 1;
    while(leftPointer < rightPointer){
        let sum = nums[leftPointer] + nums[rightPointer];
        if(sum == target){ 
            return [leftPointer,rightPointer];
        } else if(sum < target){
            leftPointer++;
        } else {
            rightPointer--;
        }
    }
    return false;
}
//let arrVal = [1,3,7];
//let arrVal = [4, -9, 0, 11, 6, -20, 1, 7];
let arrVal = [2,3,4];
console.log(twoSum(arrVal, 6));
//console.log(twoSum(arrVal, -15)); 