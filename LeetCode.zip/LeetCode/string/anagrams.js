/*
  str1 = 'hello'
  str2 = 'olleh'
  obj = {
       h:1
       e:1
       l:2
       o:1
  }
  decremet after value found from object
*/

const anagrams = (s, t)=>{
    if(s.length != t.length) return false;
    let counter = {};
    for (const letter of s) {
        counter[letter] = (counter[letter] || 0)+1;
        //counter[letter] = (counter[letter]) ? counter[letter] + 1 : 1;
    }

    for(const items of t){
        if(!counter[items]) return false;
        counter[items]-=1;
    }
    console.log(counter);
    return true;
}

console.log(anagrams('aacc','ccac'));