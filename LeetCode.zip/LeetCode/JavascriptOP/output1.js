
/*
let obj = [{
    name: "pratik"
},
{
    name: "pratik"
},
{
    name: "prafulla"
}
];

//console.log([...new Set(obj.map(x=>x.name))]);
let newArr = [];
const uniqueArr = obj.filter((val,index,array)=>{
    return val === array.find(x=>x.name === val.name);
});
console.log(uniqueArr);
*/

let arr = [1, 2, 3];
let str = "1,2,3";

console.log(arr == str);

