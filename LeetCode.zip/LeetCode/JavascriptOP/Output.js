// 4. Consider the two functions below. Will they both return the same thing? Why or why not?

function foo1()
{
  return {
      bar: "hello"
  };
}

function foo2()
{
  return
  {
      bar: "hello"
  };
}


console.log("foo1 returns:");
console.log(foo1());
console.log("foo2 returns:");
console.log(foo2());

/*
The reason for this has to do with the fact that semicolons are technically optional in JavaScript (although omitting them is generally really bad form). 
As a result, when the line containing the return statement (with nothing else on the line) is encountered in foo2(), 
a semicolon is automatically inserted immediately after the return statement.

*/

console.log("..................................");
// 3. What will the code below output to the console and why?

var myObject = {
    foo: "bar",
    func: function() {
        var self = this;
        console.log("outer func:  this.foo = " + this.foo);
        console.log("outer func:  self.foo = " + self.foo);
        (function() {
            console.log("inner func:  this.foo = " + this.foo);
            console.log("inner func:  self.foo = " + self.foo);
        }());
    }
};
myObject.func();

/* 
In the outer function, both this and self refer to myObject 
and therefore both can properly reference and access foo.

In the inner function, though, this no longer refers to myObject. As a result, this.foo is undefined in the inner function, whereas the reference to the local variable self remains in scope and is accessible there.  

*/




console.log("....................................................");
// 2. What will the code below output to the console and why?

(function(){
  var a = b = 3;
  /*b = 3;
  var a = b;
  */
  
})();
console.log("a defined ?", +(typeof a !== 'undefined')); // false
console.log("b defined ?", +(typeof b !== 'undefined')); // true
/*
   But how can b be defined outside of the scope of the enclosing function? Well, 
   since the statement var a = b = 3; is shorthand for the statements b = 3; and var a = b;,
    b ends up being a global variable (since it is not preceded by the var keyword) and
     is therefore still in scope even outside of the enclosing function.
*/

console.log("......................................................");
/*
 1. What is a potential pitfall with using typeof bar === "object" to determine if bar is an object? How can this pitfall be avoided?
*/
var bar = null;
console.log(typeof bar === "object"); 
/*o/p : 
the surprising gotcha in JavaScript is that null is also considered an object!
true*/
// How can u be avoided this pitfall - 
console.log(bar!== null && typeof bar === "object");  // false


//What will the code below output? Explain your answer.

//console.log(0.1 + 0.2); // 0.3
console.log("..................................");

console.log(0.1 + 0.2 == 0.3); // false

function arnoEqual (num1, num2){
  return Math.abs(num1 - num2) < Number.EPSILON;
}
console.log(arnoEqual(0.1+0.2, 0.3));

console.log("..................................");

/*
8. In what order will the numbers 1-4 be logged to the console when the code below is executed? Why?
*/

(function(){
    console.log(1);
    //setTimeout(()=>console.log(2), 2000);
    //setTimeout(()=>console.log(3),0);
    console.log(4);
})();

//Similarly, setTimeout() also puts execution of its referenced function into the event queue if the browser is busy.

/*
When a value of zero is passed as the second argument to setTimeout(), it attempts to execute the specified function “as soon as possible”. Specifically, execution of the function is placed on the event queue to occur on the next timer tick. Note, though, that this is not immediate; the function is not executed until the next tick. That’s why in the above example, the call to console.log(4) occurs before the call to console.log(3) (since the call to console.log(3) is invoked via setTimeout, so it is slightly delayed).
*/
console.log("............................................................");

/*
Write a simple function (less than 160 characters) 
that returns a boolean indicating whether or not a string is a palindrome.
*/

function palidrome(str){
    str = str.replace(/\W/g,'').toLowerCase();
    return (str === str.split('').reverse().join(''));
}
console.log(palidrome("level"));
console.log("..................................");

/*
Assuming d is an “empty” object in scope, say:
Assuming d is an “empty” object in scope, say:

var d = {};
…what is accomplished using the following code?
*/

var d = {};
['zebra','horse'].forEach((k)=>{
    d[k] = undefined;
})
console.log(d);

console.log("...................................");
/*
What will the code below output to the console and why?
*/

var arr1 = "john".split('');
var arr2 = arr1.reverse();
var arr3 = "jones".split('');
arr2.push(arr3);

console.log("array 1: length=" + arr1.length + " last=" + arr1.slice(-2));
console.log("array 2: length=" + arr2.length + " last=" + arr2.slice(-2));

//to array methods like slice() as a way of referencing elements at the end of the array; e.g., a subscript of -1 indicates the last element in the array, and so on.

console.log("......................................");
//What will the code below output to the console and why ?

console.log(1 +  "2" + "2"); // 122
console.log(1 +  +"2" + "2"); // 32
console.log(1 +  -"1" + "2");  // 02
console.log(+"1" +  "1" + "2"); // 112
console.log( "A" - "B" + "2"); // NaN2
console.log( "A" - "B" + 2); // NaN

/*
The following recursive code will cause a stack overflow if the array list is too large. 
How can you fix this and still retain the recursive pattern?
*/
const  readHugeList = [];
var list = readHugeList;

var nextListItem = function(){
    var item = list.pop();
    if(item){
        // Process the list item
        nextListItem();
    }
}
/*
var list = readHugeList();

var nextListItem = function() {
    var item = list.pop();

    if (item) {
        // process the list item...
        setTimeout( nextListItem, 0);
    }
};

The stack overflow is eliminated because the event loop handles the recursion, 
not the call stack. 
When nextListItem runs, if item is not null,
 the timeout function (nextListItem) is pushed to the event queue and the function exits, 
 thereby leaving the call stack clear. 
 When the event queue runs its timed-out event, 
 the next item is processed and a timer is set to again invoke nextListItem. 
 Accordingly, the method is processed from start to finish without a direct recursive call, so the call stack remains clear, 
regardless of the number of iterations.
*/

/*
What would the following lines of code output to the console?
*/

console.log(".......................................");

console.log("0 || 1 = "+(0 || 1)); // 1
console.log("1 || 2 = "+(1 || 2)); // 1
console.log("0 && 1 = "+(0 && 1)); // 0
console.log("1 && 2 = "+(1 && 2)); // 2

console.log(".......................................");

/*
What will be the output when the following code is executed? Explain.
*/

console.log(false == '0') // true
console.log(false === '0') // false


console.log(".......................................");

var a={},
    b={key:'b'},
    c={key:'c'};

a[b]=123;
a[c]=456;

console.log(a[c]); // 456 

/*
  The output of this code will be 456 (not 123).

The reason for this is as follows: When setting an object property, 
JavaScript will implicitly stringify the parameter value. In this case, 
since b and c are both objects, 
they will both be converted to "[object Object]".
 As a result, a[b] anda[c] are both equivalent to a["[object Object]"] and can be used interchangeably. Therefore, setting or referencing a[c] is precisely the same as setting or referencing a[b]
*/

// Consider the code snippet below. What will the console output be and why?
console.log(".......................................");
(function(x){
    return (function(y){
        console.log(x);
    })(2)
})(1);

/*
An important feature of closures is that an inner function still has access to the outer function’s variables.

Therefore, in this example, since x is not defined in the inner function, the scope of the outer function is searched for a defined variable x, which is found to have a value of 1.
*/

console.log(".......................................");
var hero = {
    _name:"John Doe",
    getSecretIdentity : function(){
          return this._name
    }
}

console.log(hero.getSecretIdentity());

var stoleSecretIdentity = hero.getSecretIdentity.bind(hero);
console.log(stoleSecretIdentity()); 

/*
The first console.log prints undefined because we are extracting the method from the hero object, so stoleSecretIdentity() is being invoked in the global context (i.e., the window object) where the _name property does not exist.

One way to fix the stoleSecretIdentity() function is as follows:

var stoleSecretIdentity = hero.getSecretIdentity.bind(hero);
*/

/*
 Testing your this knowledge in JavaScript: What is the output of the following code?
*/

console.log("....................................");
var length = 10;
function fn() {
  	console.log("This Length",this.length);
}

var obj = {
  length: 5,
  method: function(fn) {
    fn();
    arguments[0]();
  }
};

obj.method(fn, 1);

/*
In the first place, as fn is passed as a parameter to the function method, the scope (this) of the function fn is window. var length = 10; is declared at the window level. It also can be accessed as window.length or length or this.length (when this === window.)

method is bound to Object obj, and obj.method is called with parameters fn and 1. Though method is accepting only one parameter, while invoking it has passed two parameters; the first is a function callback and other is just a number.

When fn() is called inside method, which was passed the function as a parameter at the global level, this.length will have access to var length = 10 (declared globally) not length = 5 as defined in Object obj.

Now, we know that we can access any number of arguments in a JavaScript function using the arguments[] array.

Hence arguments[0]() is nothing but calling fn(). Inside fn now, the scope of this function becomes the arguments array, and logging the length of arguments[] will return 2.

*/


/*
Consider the following code. What will the output be, and why?  
*/

console.log(".........................................");
function abc() {
    try {        
        throw new Error();
    } catch (x) {
        var x =  1, y = 2;
        console.log(x);
    }
    console.log(x);
    console.log(y);
};
abc();
console.log(".........................................");
/*
var statements are hoisted (without their value initialization) to the top of the global or function scope 

it belongs to, even when it’s inside a with or catch block. 
However, the error’s identifier is only visible inside the catch block. It is equivalent to:
*/
(function () {
    var x, y; // outer and hoisted
    try {
        throw new Error();
    } catch (x /* inner */) {
        x = 1; // inner x, not the outer one
        y = 2; // there is only one y, which is in the outer scope
        console.log(x /* inner */);
    }
    console.log(x);
    console.log(y);
})();

console.log(".........................................");

var x = 21;
var girl = function () {
    console.log(x); // undefined
    var x = 20;
};
girl ();
/*
Neither 21, nor 20, the result is undefined

It’s because JavaScript initialization is not hoisted.

(Why doesn’t it show the global value of 21? The reason is that when the function is executed, it checks that there’s a local x variable present but doesn’t yet declare it, so it won’t look for global one.)
*/
console.log("..................................");
 /*for (let i = 0; i < 5; i++) {
    setTimeout(function() { console.log(i); }, i * 1000 );
  }*/

  console.log("..................................");

/*
  https://github.com/Vasu7389/JavaScript-Interview-Questions
  https://github.com/lydiahallie/javascript-questions
  /*
    It will print 0 1 2 3 4, because we use let instead of var here. The variable i is only seen in the for loop’s block scope.
  */

/*

*/
console.log(1 < 2 < 3);
console.log(3 > 2 > 1);

/*
The first statement returns true which is as expected.

The second returns false because of how the engine works regarding operator associativity for < and >. It compares left to right, so 3 > 2 > 1 JavaScript translates to true > 1. true has value 1, so it then compares 1 > 1, which is false.
*/


/*
  How do you add an element at the begining of an array? How do you add one at the end?
*/
let myArray = ["a","b","c","d","e"];
myArray.push("end");
myArray.unshift("start");
console.log(myArray);
let myArray1 = ["a","b","c","d","e"];
console.log(["start",...myArray1, "end"]);

/* How Do u clone an object */




let obj1 = {a:1, b:2, c:{
    age:30
}};
let objClone = Object.assign({},obj1);
console.log(objClone);

obj1.c.age = 40;

console.log('After Change - obj: ', obj1);           // 40 - This also changes
console.log('After Change - objClone: ', objClone); // 40

/*
Now the value of objclone is {a: 1 ,b: 2} but points to a different object than obj.
Note the potential pitfall, though: Object.assign() will just do a shallow copy, 
not a deep copy. This means that nested objects aren’t copied. 
They still refer to the same nested objects as the original:
*/

console.log(".............................");

var b = 1;
function outer(){
   	var b = 2
    function inner(){
        b++;
        console.log(b)
        var b = 3;
        console.log(b)
    }
    inner();
}
outer();


/*
   What is NaN? What is its type? How can you reliably test if a value is equal to NaN?
 */

   /*
     The NaN property represents a value that is “not a number”. This special value results from an operation that could not be performed either because one of the operands was non-numeric (e.g., "abc" / 4)
   */

     /*
       For one thing, although NaN means “not a number”, its type is, believe it or not, Number:

console.log(typeof NaN === "number");  // logs "true"
Additionally, NaN compared to anything – even itself! – is false:

console.log(NaN === NaN);  // logs "false"
     */

for(var i =0;i<5;i++){
    (function(x){
     setTimeout(function(){
        console.log(x);
     }, 100)
    })(i);
}
/*
  The code sample shown will not display the values 0, 1, 2, 3, and 4 as might be expected; rather, it will display 5, 5, 5, 5, and 5.

The reason for this is that each function executed within the loop will be executed after the entire loop has completed and all will therefore reference the last value stored in i, which was 5.

Closures can be used to prevent this problem by creating a unique scope for each iteration, storing each unique value of the variable within its scope, as follows:

This will produce the presumably desired result of logging 0, 1, 2, 3, and 4 to the console.

In an ES2015 context, you can simply use let instead of var in the original code:

for (let i = 0; i < 5; i++) {
	setTimeout(function() { console.log(i); }, i * 1000 );
}
*/

console.log("................. Type Of .............");
console.log(typeof typeof 1);

/*
   string

typeof 1 will return "number" and typeof "number" will return string
*/

/*
What is the value of typeof undefined == typeof NULL?
*/
console.log(typeof undefined == typeof NULL);
/*
The expression will be evaluated to true, since NULL will be treated as any other undefined variable
*/

/*
  Imagine you have this code:
*/

console.log("Array of Array");
var a  = [1,2,3];
a[10] = 99;
console.log(a[6]);
console.log(a[10]);
console.log("..........");