/*
Removed Duplicate  from sorted array;
 rd i
[2, 2, 3, 3, 4, 6, 6]
*/
/*
const removeDuplicate = (a) => {
    let rd = 0;
    for (let i = 1; i < a.length; i++) {
        if (a[rd] != a[i]) {
            rd++;
            a[rd] = a[i];
        }
    }
    return a.slice(0, rd + 1);
}

console.log(removeDuplicate([2, 2, 3, 3, 4, 6, 6]));
*/
const duplicateArr = [14, 23, 6, 6, 14, 56, 87, 14];

let uniqueArr = duplicateArr.filter((val, index, arr)=>{
        return arr.indexOf(val) === index; 
})

console.log(uniqueArr);


const dupArr = [{name:"prafulla", age:20},{name:"pratik", age:20}, {name:"prafulla", age:35}];

let unArr = dupArr.filter((ele,index, arr)=>{
      //return arr.findIndex(val => val.name === ele.name) === index; 
      return arr.find(val => val.age === ele.age) === ele;
})
console.log("unArr", unArr);
/*
 val   arr.indexOf    index  uniqueArr   flag 
 14      1             1      14         true 
 23      2             2      23         true
 6       3             3       6         true
 6       3             4       6         false  
*/