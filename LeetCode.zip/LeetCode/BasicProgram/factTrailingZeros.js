
/*
 5! = 120
 5/5 
*/

const factTraiZero = (n)=>{
    let res = 0, powOf5 = 5;
    while(n>=powOf5){
         res = res + Math.floor((n/powOf5));
         powOf5  = powOf5 * 5;
    }
    return res;
}

console.log(factTraiZero(200));
