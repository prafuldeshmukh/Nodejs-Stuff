/*
   5! = 1*2*3*4*5
   res = 1
   1*1 = 1
   1*2 = 2
   2*3 = 6
*/

const fact = (n) =>{
    let res = 1;
    for(let i = 1;i<=n;i++){
         res = res * i;
    }
    return res;
}
console.log(fact(5))