/*
   n(n+1)/2
   10(11)/2  = 55
   0,1,2,3,5,6,7,8,9,10 = 51
    55 - 51 =4;
*/
const missingNo = (nums) => {
    let n = nums.length;
    let expectedTotal = (n * (n + 1)) / 2;
    //console.log(expectedTotal);
    let total = 0;
    for (let i = 0; i < nums.length; i++) {
        total += nums[i];
    }
    //console.log(total);
    return expectedTotal - total;
}
console.log(missingNo([0,2,7,8,1,4,3,6]));



const findAllMissingNo = (nums) => {
    let maxNo = Math.max(...nums);
    let minNo = Math.min(...nums);
    let finArr = [];
    for(let k = minNo;k<=maxNo;k++){
        if(!nums.includes(k)){
            finArr.push(k);
        }
    }    
    console.log(finArr);
}
console.log(findAllMissingNo([0,2,7,8,1,4,3,6, 12]));


