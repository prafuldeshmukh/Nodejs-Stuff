
/*
    a -> [20,20,30,30,30,40];
           0  1  2  3  4 5

     20 2
     30 4   
     40 1    
*/

const findFrequencyOfElem = (a)=>{
       let freq = 1;
       let i = 1;
       while(i<a.length){

         while(i<a.length && a[i] === a[i-1]){
            freq++;
            i++;
         }
         console.log(a[i-1] + " " + freq);
         freq = 1;
         i++;
       }
       if(a[i-1]!=a[i-2]){
        console.log(a[i-1] + " " + freq);
       }
}


console.log(findFrequencyOfElem([20,20,30,30,30,40]));
console.log(findFrequencyOfElem(["Hello","world","java"]));