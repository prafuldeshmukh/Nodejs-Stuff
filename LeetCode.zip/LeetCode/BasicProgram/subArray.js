/*
   a = [1,2,3,4,5];
*/

const subArray  = (nums)=>{
   for(let i = 0;i<nums.length;i++){
      for(let j = i;j<nums.length;j++){
         for(let k = i;k<j;k++){
            console.log(nums[k]);
         }
         console.log(" ............. ");
      }
   }
}

console.log(subArray([1,2,3,4,5]));