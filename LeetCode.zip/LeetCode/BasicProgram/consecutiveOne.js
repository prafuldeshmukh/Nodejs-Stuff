/*       0 1  2  3 4 5 6  7 8
    a-> [0,1, 1, 0,0,1,1,1, 0]
    count  = 0, maxCount = 3
*/

const consecutiveOne = (a)=>{
    let maxCount = 0, count = 0;
    for(let i =0;i<a.length;i++){
        if(a[i] == 0){
            count = 0;
        }else {
            count++;
            maxCount = Math.max(count,maxCount);
        }
    }
    return maxCount;
}

console.log(consecutiveOne([0,1, 1, 0,0,1,1,1, 0]));