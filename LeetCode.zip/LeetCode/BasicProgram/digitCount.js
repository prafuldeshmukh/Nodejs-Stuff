/*
  1. Check if digit exists n > 0
  2. Remove the last digit no - n % 10
  3. Increase the value of count by 1 - count + 1
  4. Repeat step1 & step3 till remain digit
*/

const countDigit = (n)=>{
    let count = 0;
    while(n>0){
        n = Math.floor(n / 10);
        count++;
    }
    return count;
}

console.log(countDigit(2357));

