/*
nums = [2,3,1,1,4]


*/

const jumpGame = (nums) => {
    let reachable = 0;
    let n = nums.length;
    for (i = 0; i < n; i++) {
        console.log("reachable",reachable, "i", i);
        console.log(reachable < i);
        
         if(reachable < i){
            return false;
         }
         console.log(i+nums[i]);
         reachable = Math.max(reachable, i+nums[i]);
    }
    return true;

};
console.log(jumpGame([2,5,0,0]));

/*
   [2,3,1,1,4]
   reachable = 2
   
*/