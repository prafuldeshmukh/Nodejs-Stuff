

const flattenAsync = (arr)=>{
    return new Promise((resolve, reject) =>{
          if(!Array.isArray(arr)){
            reject(new Error("Input is not an array"));
            return;
          }
          
          let result = [];
          const recursiveFlatten = (inputArr)=>{
               for(let i = 0; i<inputArr.length;i++){
                  if(Array.isArray(inputArr[i])){
                    console.log("Before Recurisve:",result);
                    recursiveFlatten(inputArr[i]);
                    console.log("After Recurisve:",result);
                  } else {
                    result.push(inputArr[i]);
                  }
               } 
          }          
          recursiveFlatten(arr);
          setTimeout(()=>{
             resolve(result);
          }, 1000);  
    });
   
}

flattenAsync([[2,3,[6,7,8,[9,20]]]]).then(res => console.log(res)).catch(err=> console.log(err.message));