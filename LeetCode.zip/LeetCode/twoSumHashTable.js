/*
nums  = [2,7,11,15];

hash = {
    2:0,
    7:1,
    11:2,
    15: 3
}
nums  = 2, 7, 11, 15
index = 0  1   2   3
*/

const twoSumHash = (nums, target) => {
    let hashMap = {};
    /*for(let i = 0; i<nums.length;i++){
        hashMap[nums[i]] = i;
    }*/
    for (let j = 0; j < nums.length; j++) {
        let potentialKey = target - nums[j];
        if (hashMap[potentialKey] >= 0 && hashMap[potentialKey] !== j) {
            return [hashMap[potentialKey], j];
        } else {
            hashMap[nums[j]] = j;
        }
    }
    console.log("HashMap", hashMap);
}

/* 
  [3,2,3]
 target  pk   hashMap[potentialKey] >=0    hasmap
  6      3     false                       3 : 0
         4     false                       2 : 1
         3     true 
*/


console.log(twoSumHash([2, 7, 18, 9], 20));

console.log(twoSumHash([3,2,3], 6));

