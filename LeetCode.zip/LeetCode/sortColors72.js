/*
   [2,0,2,1,1,0]
   [0,0,1,1,2,2]
   Without sort 
   //You must solve this problem without using the library's sort function
   0 = 2
   1 = 2
   2 = 2   
*/

const sortColors = (nums)=>{
      let zero = 0, one =0, two = 0;
      for(let i = 0; i< nums.length; i++){
          if(nums[i] === 0) zero++;
          if(nums[i] === 1) one++;
          if(nums[i] === 2) two++;
      }

      for(let i = 0;i<zero;i++){
         nums[i] = 0;
      }
      for(let i = zero;i<one+zero;i++){
         nums[i] = 1;
      }
      for(let i = one+zero;i<nums.length;i++){
        nums[i] = 2;
     }
     return nums;
}

console.log(sortColors([2,0,2,1,1,0]));