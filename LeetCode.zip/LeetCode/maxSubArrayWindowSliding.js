/*  
https://www.youtube.com/watch?v=jhW7VwP2Djw
     0  1   2   3   4  5
    a => 2, 9, 31, -4, 21, 7
    k = 3 
    wSum = 0;
    mSum = -999999;

     2 + 9 + 31 = 42
     wSum = 42

     wsum = wsum - a[i-k] + a[i]
     mSum = max(wsum, mSum);
*/
const maxSubArray = (a, k) => {
    let wSum = 0;
    let mSum = -99999;
    for (let i = 0; i < k; i++) {
        wSum += a[i];
    }

    for(let i = k;i<a.length;i++){
        wSum = wSum - a[i-k] + a[i];
        mSum  = Math.max(mSum,wSum);
    }
    return mSum;
}

console.log(maxSubArray([2, 9, 31, -4, 21, 7], 3))



