/*
[-1,0,1,2,-1,-4]
sort an array 
-4, -1, -1, 0, 1, 2
         i   j    k

i = 0 - (-1) = 1
j = 0 + 2 = 2 
*/


const threeSum = (nums) => {
    nums.sort((a, b) => a - b);
    let result = [];
    for (let i = 0; i < nums.length; i++) {
        if (i == 0 || nums[i] != nums[i - 1]) {
            let target = 0 - nums[i];
            let subResult = twoSum(i+1,nums.length -1, target, nums);
            result.push(...subResult);
        }
    }
    return result;
}

const twoSum = (j,k, target, nums)=>{
    let a1 = nums[j-1];
    let result = [];
    while(j<k){
        if(nums[j]+nums[k]>target){
              k--;
        } else if(nums[j]+nums[k] < target){
              j++;
        } else {
             result.push([a1,nums[j], nums[k]]);
             // Remove duplicate j 
             while(j<k && nums[j] === nums[j+1]) j++;
             // Remove duplicate k
             while(j<k && nums[k] === nums[k-1]) k--;
             j++;
             k--;
        }
    }
    return result;
}

console.log(threeSum([-1,0,1,2,-1,-4]));