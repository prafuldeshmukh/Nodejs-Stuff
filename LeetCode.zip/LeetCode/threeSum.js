/*
Input: nums = [-1,0,1,2,-1,-4]
Output: [[-1,-1,2],[-1,0,1]]
-1 0 1 2 -1 -4

-4 -1 -1 0 1 2
i    j        k

i    j        k      target                     
-4    -1       2      nums[i] * -1 = -4 * -1 = 4

 target = -1 * 2 = -2
  
*/

const threeSum = (nums)=>{
      nums.sort((a,b)=> a -b);
      const result = [];

      for(let i = 0; i<nums.length;i++){
          if(nums[i] === nums[i-1]) continue;
          let target = nums[i] * -1;
          let subResult = twoSum(i+1, target, nums);
          result.push(...subResult);
      }
      return result;
}

const twoSum = (j, target, nums)=>{
    let k = nums.length - 1;
    let result = [];

    while(j<k){
        let leftVal = nums[j];
        let rightVal = nums[k];

        if(leftVal + rightVal > target){
            k--;
        }else if(leftVal + rightVal < target){
            j++;
        }else {
            result.push([(target * -1),leftVal, rightVal]);
            while(j < k && nums[j] === nums[j+1]) j++;
            while(j<k && nums[k] === nums[k+1]) k--;
            j++;
            k--;
        }
    }
    return result;
}

console.log(threeSum([-1,0,1,2,-1,-4]));