/*
  Problem Statement:
   [7, 1, 5 , 3, 6, 4];
  //a single day to buy one stock and choosing a different day in the future to sell that stock
  // Return the maximum profit you can achieve from this transaction
  // that buying on day 2 and selling on day 1 is not allowed because you must buy before you sell
  // Same day u can't buy & sell
  // if it is in loss or -1 show o/p as 0
  Intuition
     Buy on loweset price
     Sell on the highest price
  Approach
    [7, 1, 5 , 3, 6, 4];
    curr  = 7, Min  = 7, Profit = 0 , max     
  Code 
  Complexity 
  Time Complexity : Your check every no at once o(n)
  Space Complexity : o(1) - contant space
*/

const stockMaxProfit = (prices)=>{
    let profit = 0, maxProfit = 0, min = prices[0];
    if(prices.length === 0) return 0;
    for(let stockPrice of prices){
        min = Math.min(min, stockPrice);
        profit = stockPrice - min;
        maxProfit = Math.max(profit, maxProfit);
    } 
    return maxProfit;
}

console.log(stockMaxProfit([7,6,4,3,1]));




