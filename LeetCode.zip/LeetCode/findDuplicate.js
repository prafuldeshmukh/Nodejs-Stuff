/*
  Problem Statement :
  [1,3,4,2,2]
  Approch1 : Sort [1,2,2,3,4]
             check arr[i] == arr[i+1];

   Approch2 :
   frequency count = [0,1,2,3,4,5]          
                      0 1 2 0 1 0

   Approch 3 with same sapce :
           0,1, 2, 3, 4,   5                   
             -1 -2  -1  -1 -1 
*/

const findDuplicate = (nums)=>{
    for(let i = 0;i<nums.length;i++){
        let index = Math.abs(nums[i]);
        if(nums[index] < 0) return index;
        nums[index] = - nums[index];
        console.log("nums", nums);
    }
    return -1;
}

console.log(findDuplicate([1,3,4,2,4]));