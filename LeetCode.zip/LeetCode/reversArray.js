/*
   Reverase An Array 
   Using An Extra Space 
   Using Same Array
   Recursive Approch
*/
const reverArr = (nums) =>{
    let newDataArr = [];
    for(let i = nums.length -1;i >= 0;i--){
        newDataArr.push(nums[i]);
    }
    return newDataArr;
}

console.log(reverArr([-1, 1,2,3,4,5 ]));
// TC - O(N), SC - O(N)

//But actually requirement  You must do this by modifying the input array in-place with O(1) extra memory
