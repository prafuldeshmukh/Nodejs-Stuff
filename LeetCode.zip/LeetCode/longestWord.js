/*

*/

const findLongestWord = (words) => {
    let longestWord = '';
    let wordsArr = words.split(' ');
    for (let i = 0; i < wordsArr.length; i++) {
        if (wordsArr[i].length > longestWord.length) {
            longestWord = wordsArr[i];
        }
    }
    return longestWord;
}


console.log(findLongestWord('The quick brown fox jumps over the lazy dog'));