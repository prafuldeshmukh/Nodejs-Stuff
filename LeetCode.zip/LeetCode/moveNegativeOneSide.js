/*

Two Pointer Method

-1 2 -3 8 9 -6 3
 l             r

*/


const moveNegPos = (arr) => {
    let left = 0, right = arr.length - 1;
    while (left < right) {
        while (arr[left] < 0) left++;
        while (arr[right] > 0) right--;

        while (left >= right) break;
        let temp = arr[left];
        arr[left] = arr[right];
        arr[right] = temp;
    }
    return arr;

}

console.log(moveNegPos([-1, 2, -3, 4, 5, 6, -7, 8, 9, -6, 3]));