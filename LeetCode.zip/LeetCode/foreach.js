/*
const array = [1, 2, 3, 4, 5];
array.forEach(async (el, i) => {
    //setTimeout(() => {
        //console.log(el);
    //}, 1000);
    await iterateFun(i);
});
async function iterateFun(i){
    console.log(i);    
    console.log("I am here");
}
*/


const getWinners = async()=>{
    return [1,2,3,4,5];
}

//


const sendEmailToAdmin = async ()=>{
  console.log('All prizes awarded');

}
const givePrizeToPlayer = async (player)=>{
  console.log("Player", player);
}



async function handleData (){
    
const players = await getWinners();

players.forEach(async player => {
    try{
      if(player == 2){
        throw new Error("Error");
    } else {
        await givePrizeToPlayer(player);
  
    }
} catch(err){
    console.log(err);
}
    
});

await sendEmailToAdmin();

}
handleData();
