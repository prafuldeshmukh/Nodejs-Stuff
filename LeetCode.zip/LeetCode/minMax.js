
const findMinMax = (nums) =>{
    if(nums.length == 0) return 'No number found';
    let min = nums[0];
    let max = nums[1];
    for(let i =0;i<nums.length;i++){
          if(nums[i] < min){
              min = nums[i];
          }
          if(nums[i] > max){
            max = nums[i]
          }
    }
    console.log("Min Number", min);
    console.log("Max Number", max);
}

console.log(findMinMax([2,3,1,4,5,6,10]));